# FDE Radar Playbook

Updated Oct 2026 · https://fderadar.com

Contents: [Prompts](#prompts) · [Workflows](#workflows) · [Skills checklists](#skills-checklists) · [AI tips](#ai-tips)

## Prompts

### Demo prep

#### Build a tailored demo story

```text
Our product features: [LIST]. Prospect pains from discovery: [LIST]. Build a 20-minute demo flow: opening hook tied to their top pain, 3 scenes (pain → feature → outcome), and a close asking for a specific next step. Cut any feature that doesn't map to a pain.
```

#### Generate realistic demo data

```text
Generate 25 rows of realistic but fake sample data for a [INDUSTRY] demo of [USE CASE] as CSV with columns [COLUMNS]. Include 3 edge cases that would make the demo more convincing. No real company or person names.
```

#### Pre-mortem my demo

```text
Here is my demo outline: [PASTE]. Act as a skeptical [BUYER ROLE]. List the 7 moments where you would lose interest or push back, and how I should fix each.
```

### Discovery

#### Discovery call prep

```text
I have a discovery call with [COMPANY], a [INDUSTRY] company, with [ROLE OF ATTENDEES]. Our product does [ONE-LINE PRODUCT]. Using only public info I paste below, list: 5 likely business pains, 10 open-ended discovery questions ranked by importance, and 3 signals that this is NOT a fit. Info: [PASTE]
```

#### Turn call notes into a deal summary

```text
Here are raw notes from a discovery call: [PASTE]. Rewrite them as: current state, desired outcome, metrics they care about, decision process, technical environment, risks, and open questions. Flag anything I assumed but they did not say.
```

#### Map the stakeholders

```text
From this email thread and call notes [PASTE], build a stakeholder map: name, title, what they care about, likely objection, influence (high/med/low). Suggest one question to ask each person next.
```

### Implementation plans

#### 30-60-90 implementation plan

```text
Create a 30-60-90 day implementation plan for [CUSTOMER] deploying [PRODUCT] for [USE CASE] with [TEAM SIZE]. Include milestones, dependencies, customer-side owners, risks, and what 'live' means at day 90.
```

#### Risk register

```text
From this project plan [PASTE], build a risk register table: risk, likelihood, impact, early warning sign, mitigation, owner. Add 3 risks the plan doesn't mention but deployments like this commonly hit.
```

#### Runbook from tribal knowledge

```text
Here's a messy Slack thread about how we set up [SYSTEM] for a customer: [PASTE]. Turn it into a numbered runbook with prerequisites, steps, verification checks, and rollback steps.
```

### Objection handling

#### Objection response drafts

```text
Prospect objection: "[OBJECTION]". Context: [DEAL CONTEXT]. Give 3 responses: one that asks a clarifying question, one that reframes with a business outcome, one that offers proof (POC, reference, doc). Keep each under 60 words.
```

#### Competitive positioning

```text
We're competing with [COMPETITOR] for [USE CASE]. From the public info I paste [PASTE], list where they are genuinely stronger, where we are, and 4 discovery questions that surface our strengths honestly. Don't invent claims about them.
```

#### Build vs buy rebuttal

```text
The customer's engineering team says they can build this in-house. Draft a respectful talk track covering total cost of ownership, time to value, maintenance, and what they'd still own. Include 3 questions to quantify their build estimate.
```

### POC scoping

#### Scope a proof of concept

```text
Draft a POC scope for [COMPANY] testing [PRODUCT] for [USE CASE]. Include: objective, 3–5 measurable success criteria, in/out of scope, data and access needed from them, timeline by week, owners on both sides, and exit decision. Keep it to one page.
```

#### Pressure-test success criteria

```text
Here are proposed POC success criteria: [PASTE]. For each, say if it is measurable, who measures it, how it could be gamed or misread, and rewrite vague ones into concrete pass/fail tests.
```

#### Data and security questionnaire prep

```text
The customer sent this security/IT questionnaire: [PASTE]. Using our documentation [PASTE], draft answers. Mark any question where our docs don't clearly support an answer as NEEDS REVIEW instead of guessing.
```

### Stakeholder updates

#### Weekly customer status update

```text
Write a weekly status email for [CUSTOMER] from these notes [PASTE]: green/yellow/red status, done this week, next week, blockers needing their action (with owner and date), decisions needed. Under 200 words.
```

#### Escalation email

```text
Draft a calm escalation email to [CUSTOMER EXEC] about [ISSUE]: what happened, impact, what we've done, what we need from them, and the date of the next update. No blame, no hedging.
```

#### Internal deal debrief

```text
Summarize this deal for my internal team from these notes [PASTE]: why we won/lost, what the customer actually valued, product gaps raised, and 3 lessons for the next similar deal.
```

#### Executive business review

```text
Draft an EBR outline for [CUSTOMER] after [N] months using these usage metrics and outcomes [PASTE]: goals vs results, value delivered, adoption gaps, roadmap asks, and a proposed expansion next step. Only use the numbers provided.
```

### Technical writeups

#### Architecture explainer for execs

```text
Explain this integration architecture [PASTE DIAGRAM DESCRIPTION OR NOTES] to a non-technical VP in under 200 words: what connects to what, where their data goes, and what their team has to do. No jargon without a plain-English gloss.
```

#### Write a solution design doc

```text
Turn these notes into a solution design doc with sections: context, requirements, proposed design, integrations, data flow, security considerations, alternatives considered, open questions. Notes: [PASTE]
```

#### Debug log triage

```text
Here is an error log from a customer environment: [PASTE]. Summarize what likely failed, the 3 most probable root causes in order, and the exact next diagnostic step for each. Say clearly if the log is insufficient.
```

## Workflows

### Discovery-to-brief in 15 minutes

Discovery · 5 steps

1. Record the call with an approved notetaker (e.g. Fathom, Granola).
2. Paste the transcript into your AI tool with the 'deal summary' prompt.
3. Ask it to list every assumption not stated by the customer.
4. Fix gaps, then generate a 5-bullet brief for your AE and a follow-up email draft.
5. Log the brief in CRM and set next-step dates.

### Account research before first call

Discovery · 5 steps

1. Collect the company's site, latest 10-K or press releases and the attendees' LinkedIn roles.
2. Prompt: summarize business model, likely priorities, recent changes.
3. Generate 10 discovery questions ranked by importance.
4. Flag 3 'not a fit' signals to watch for.
5. Save it as a one-page call plan.

### Tailored demo in an hour

Demo prep · 5 steps

1. List the top 3 pains from discovery.
2. Prompt the demo-story template to map pain → feature → outcome.
3. Generate fake but realistic demo data as CSV and load it into your sandbox.
4. Run the 'pre-mortem my demo' prompt as the skeptical buyer.
5. Record a 3-minute Loom of the flow for async stakeholders.

### POC scope that gets signed

POC · 5 steps

1. Draft the scope with the POC prompt (objective, criteria, timeline, owners).
2. Pressure-test each success criterion for measurability.
3. Review with the champion; agree on pass/fail before kickoff.
4. Turn the timeline into a shared checklist with dates.
5. Send a recap email confirming criteria in writing.

### Agent POC with evals

POC · 5 steps

1. Pick one narrow task and collect 20–50 real example inputs (with permission).
2. Build the first version with an agent framework (e.g. LangGraph, OpenAI Agents SDK).
3. Write expected outputs and run them through an eval tool (e.g. promptfoo, DeepEval).
4. Trace failures with an observability tool (e.g. Langfuse, LangSmith).
5. Report pass rate against the agreed criteria, not vibes.

### Security questionnaire first pass

Security · 5 steps

1. Gather your approved security docs (SOC 2 summary, DPA, architecture).
2. Prompt the AI to answer only from those docs and mark gaps NEEDS REVIEW.
3. Route NEEDS REVIEW items to security/legal owners.
4. Store final answers in your RFP tool (e.g. Loopio, Responsive) for reuse.
5. Track turnaround time per questionnaire.

### Integration debugging loop

Implementation · 5 steps

1. Reproduce the issue and capture logs, request/response and environment.
2. Paste logs into the triage prompt for ranked root causes.
3. Test the top hypothesis with Postman or a small script.
4. Document the fix as a runbook entry.
5. Share a plain-English summary with the customer.

### 30-60-90 implementation plan

Implementation · 5 steps

1. Feed scope, team size and success criteria into the 30-60-90 prompt.
2. Generate a risk register and add customer-specific risks.
3. Assign customer-side owners for every dependency.
4. Review in the kickoff meeting and get explicit agreement.
5. Turn milestones into weekly status-update headings.

### Weekly status update on autopilot

Stakeholders · 5 steps

1. Keep a running notes doc per customer during the week.
2. Friday: paste notes into the status prompt (RAG status, done, next, blockers).
3. Check every owner and date is real.
4. Send it and pin it in the shared channel.
5. Escalate any red item with the escalation prompt the same day.

### Runbook from Slack chaos

Implementation · 5 steps

1. Export the relevant thread(s).
2. Prompt the AI to produce a numbered runbook with checks and rollback.
3. Follow the runbook yourself once on a test environment.
4. Fix steps that fail, then publish to your wiki.
5. Link the runbook in future tickets.

### Deal debrief → product feedback

Stakeholders · 5 steps

1. After win/loss, paste notes into the debrief prompt.
2. Extract product gaps with customer quotes you actually heard.
3. Group gaps by theme and deal size.
4. Share with product monthly in a single doc.
5. Track which gaps ship and tell the customer.

### EBR deck in an afternoon

Stakeholders · 5 steps

1. Export usage metrics and outcomes for the period.
2. Prompt the EBR outline using only the provided numbers.
3. Add one customer story and one adoption gap.
4. Propose a specific expansion next step.
5. Rehearse with the champion before the exec meeting.

## Skills checklists

Tick each one off as you finish it.

## Technical foundations

- [ ] Command line, git, debugging basics: [MIT Missing Semester](https://missing.csail.mit.edu/)
- [ ] Git branching, interactively: [Learn Git Branching](https://learngitbranching.js.org/)
- [ ] CS fundamentals: [Harvard CS50x](https://cs50.harvard.edu/x/)
- [ ] Python: [LearnPython.org](https://www.learnpython.org/)
- [ ] SQL: [SQLBolt](https://sqlbolt.com/)
- [ ] HTTP & APIs: [MDN HTTP docs](https://developer.mozilla.org/en-US/docs/Web/HTTP)
- [ ] Containers: [Docker Get Started](https://docs.docker.com/get-started/)
- [ ] DevOps / cloud roadmap: [roadmap.sh DevOps](https://roadmap.sh/devops)
- [ ] Web dev end to end: [The Odin Project](https://www.theodinproject.com/)

## AI & LLM skills

- [ ] Prompt engineering (OpenAI): [OpenAI guide](https://platform.openai.com/docs/guides/prompt-engineering)
- [ ] Prompt engineering (Anthropic): [Anthropic guide](https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/overview)
- [ ] Prompting for developers: [DeepLearning.AI short course](https://learn.deeplearning.ai/courses/chatgpt-prompt-eng)
- [ ] LLMs & transformers: [Hugging Face LLM course](https://huggingface.co/learn/llm-course)
- [ ] Connecting AI to tools/data: [Model Context Protocol docs](https://modelcontextprotocol.io/introduction)

## Customer & presales skills

- [ ] Presales community and content: [PreSales Collective](https://www.presalescollective.com/)
- [ ] API testing for demos/POCs: [Postman API testing](https://www.postman.com/api-platform/api-testing/)

### Customer skills

- [ ] Run a discovery call that ends with clear pains, metrics and next step
- [ ] Build a demo tied to customer pains, not a feature tour
- [ ] Scope a POC with measurable pass/fail criteria
- [ ] Write a one-page solution design a VP can read
- [ ] Handle an objection by asking before answering
- [ ] Run a weekly status update with owners and dates
- [ ] Build a working integration end to end (API → data → output) and explain it

## AI tips

- **Give the model the role and the reader** Say who it is writing as and for whom (e.g. 'a CFO who skims'). Output changes more from audience than from adjectives.
- **Paste the source, don't describe it** Paste call notes, docs or logs. Summaries of summaries lose the details that matter.
- **Ask it to flag gaps instead of guessing** Add 'If the input doesn't support an answer, write NEEDS REVIEW.' This cuts made-up details in customer-facing work.
- **Use structure for reusable outputs** Request fixed sections or a table so status updates and POC docs look the same every week.
- **Iterate in two passes** First ask for a draft, then ask it to critique the draft as the skeptical buyer, then revise.
- **Keep a personal prompt library** Save prompts that worked with your [BRACKET] variables. Our prompts page is a starting point.
- **Check your company's data policy first** Don't paste customer data, credentials or contracts into tools your company hasn't approved.
- **Verify every number and claim** Treat model output as a draft. Check figures, product capabilities and competitor claims before they reach a customer.
- **Use AI for demo data, not demo truth** Generate fake but realistic sample data; never let the model invent features your product doesn't have.
- **Turn tribal knowledge into runbooks** Paste Slack threads and ask for numbered steps with verification and rollback. Then test the runbook once yourself.
- **Prep with a role-play** Ask the model to play the skeptical buyer or security reviewer and run through your demo or answers.
- **Learn how your tools connect to AI** Standards like the Model Context Protocol let assistants reach your tools and data; understanding them is quickly becoming part of deployment work.

---
New prompts and workflows every Friday: https://fderadar.com/newsletter
