---
name: security-questionnaire-first-pass
description: "Security questionnaire first pass: a 5-step security workflow for forward deployed engineers and solutions engineers."
---

# Security questionnaire first pass

Category: Security

Follow these steps in order:

1. Gather your approved security docs (SOC 2 summary, DPA, architecture).
2. Prompt the AI to answer only from those docs and mark gaps NEEDS REVIEW.
3. Route NEEDS REVIEW items to security/legal owners.
4. Store final answers in your RFP tool (e.g. Loopio, Responsive) for reuse.
5. Track turnaround time per questionnaire.

Source: FDE Radar workflows, https://fderadar.com/workflows.html
