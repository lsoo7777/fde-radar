---
name: ebr-deck-in-an-afternoon
description: "EBR deck in an afternoon: a 5-step stakeholders workflow for forward deployed engineers and solutions engineers."
---

# EBR deck in an afternoon

Category: Stakeholders

Follow these steps in order:

1. Export usage metrics and outcomes for the period.
2. Prompt the EBR outline using only the provided numbers.
3. Add one customer story and one adoption gap.
4. Propose a specific expansion next step.
5. Rehearse with the champion before the exec meeting.

Source: FDE Radar workflows, https://fderadar.com/workflows.html
