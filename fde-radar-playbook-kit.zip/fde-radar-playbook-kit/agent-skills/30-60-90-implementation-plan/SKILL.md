---
name: 30-60-90-implementation-plan
description: "30-60-90 implementation plan: a 5-step implementation workflow for forward deployed engineers and solutions engineers."
---

# 30-60-90 implementation plan

Category: Implementation

Follow these steps in order:

1. Feed scope, team size and success criteria into the 30-60-90 prompt.
2. Generate a risk register and add customer-specific risks.
3. Assign customer-side owners for every dependency.
4. Review in the kickoff meeting and get explicit agreement.
5. Turn milestones into weekly status-update headings.

Source: FDE Radar workflows, https://fderadar.com/workflows.html
