---
name: discovery-to-brief-in-15-minutes
description: "Discovery-to-brief in 15 minutes: a 5-step discovery workflow for forward deployed engineers and solutions engineers."
---

# Discovery-to-brief in 15 minutes

Category: Discovery

Follow these steps in order:

1. Record the call with an approved notetaker (e.g. Fathom, Granola).
2. Paste the transcript into your AI tool with the 'deal summary' prompt.
3. Ask it to list every assumption not stated by the customer.
4. Fix gaps, then generate a 5-bullet brief for your AE and a follow-up email draft.
5. Log the brief in CRM and set next-step dates.

Source: FDE Radar workflows, https://fderadar.com/workflows.html
