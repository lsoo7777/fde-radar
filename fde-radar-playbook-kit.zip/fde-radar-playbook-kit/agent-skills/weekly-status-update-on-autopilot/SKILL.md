---
name: weekly-status-update-on-autopilot
description: "Weekly status update on autopilot: a 5-step stakeholders workflow for forward deployed engineers and solutions engineers."
---

# Weekly status update on autopilot

Category: Stakeholders

Follow these steps in order:

1. Keep a running notes doc per customer during the week.
2. Friday: paste notes into the status prompt (RAG status, done, next, blockers).
3. Check every owner and date is real.
4. Send it and pin it in the shared channel.
5. Escalate any red item with the escalation prompt the same day.

Source: FDE Radar workflows, https://fderadar.com/workflows.html
