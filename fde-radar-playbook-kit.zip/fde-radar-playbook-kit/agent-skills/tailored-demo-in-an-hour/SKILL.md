---
name: tailored-demo-in-an-hour
description: "Tailored demo in an hour: a 5-step demo prep workflow for forward deployed engineers and solutions engineers."
---

# Tailored demo in an hour

Category: Demo prep

Follow these steps in order:

1. List the top 3 pains from discovery.
2. Prompt the demo-story template to map pain → feature → outcome.
3. Generate fake but realistic demo data as CSV and load it into your sandbox.
4. Run the 'pre-mortem my demo' prompt as the skeptical buyer.
5. Record a 3-minute Loom of the flow for async stakeholders.

Source: FDE Radar workflows, https://fderadar.com/workflows.html
