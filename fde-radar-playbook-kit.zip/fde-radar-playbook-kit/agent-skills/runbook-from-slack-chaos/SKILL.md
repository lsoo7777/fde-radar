---
name: runbook-from-slack-chaos
description: "Runbook from Slack chaos: a 5-step implementation workflow for forward deployed engineers and solutions engineers."
---

# Runbook from Slack chaos

Category: Implementation

Follow these steps in order:

1. Export the relevant thread(s).
2. Prompt the AI to produce a numbered runbook with checks and rollback.
3. Follow the runbook yourself once on a test environment.
4. Fix steps that fail, then publish to your wiki.
5. Link the runbook in future tickets.

Source: FDE Radar workflows, https://fderadar.com/workflows.html
