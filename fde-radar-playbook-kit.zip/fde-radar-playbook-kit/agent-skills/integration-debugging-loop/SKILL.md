---
name: integration-debugging-loop
description: "Integration debugging loop: a 5-step implementation workflow for forward deployed engineers and solutions engineers."
---

# Integration debugging loop

Category: Implementation

Follow these steps in order:

1. Reproduce the issue and capture logs, request/response and environment.
2. Paste logs into the triage prompt for ranked root causes.
3. Test the top hypothesis with Postman or a small script.
4. Document the fix as a runbook entry.
5. Share a plain-English summary with the customer.

Source: FDE Radar workflows, https://fderadar.com/workflows.html
