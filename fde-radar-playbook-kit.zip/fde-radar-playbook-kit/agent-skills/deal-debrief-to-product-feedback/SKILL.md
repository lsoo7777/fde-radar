---
name: deal-debrief-to-product-feedback
description: "Deal debrief → product feedback: a 5-step stakeholders workflow for forward deployed engineers and solutions engineers."
---

# Deal debrief → product feedback

Category: Stakeholders

Follow these steps in order:

1. After win/loss, paste notes into the debrief prompt.
2. Extract product gaps with customer quotes you actually heard.
3. Group gaps by theme and deal size.
4. Share with product monthly in a single doc.
5. Track which gaps ship and tell the customer.

Source: FDE Radar workflows, https://fderadar.com/workflows.html
