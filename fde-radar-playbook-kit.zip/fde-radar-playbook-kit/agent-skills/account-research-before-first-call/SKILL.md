---
name: account-research-before-first-call
description: "Account research before first call: a 5-step discovery workflow for forward deployed engineers and solutions engineers."
---

# Account research before first call

Category: Discovery

Follow these steps in order:

1. Collect the company's site, latest 10-K or press releases and the attendees' LinkedIn roles.
2. Prompt: summarize business model, likely priorities, recent changes.
3. Generate 10 discovery questions ranked by importance.
4. Flag 3 'not a fit' signals to watch for.
5. Save it as a one-page call plan.

Source: FDE Radar workflows, https://fderadar.com/workflows.html
