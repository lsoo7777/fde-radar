# Weekly customer status update

Category: Stakeholder updates

Fill in before you paste: [CUSTOMER], [PASTE]

## Prompt

```text
Write a weekly status email for [CUSTOMER] from these notes [PASTE]: green/yellow/red status, done this week, next week, blockers needing their action (with owner and date), decisions needed. Under 200 words.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
