# Executive business review

Category: Stakeholder updates

Fill in before you paste: [CUSTOMER], [N], [PASTE]

## Prompt

```text
Draft an EBR outline for [CUSTOMER] after [N] months using these usage metrics and outcomes [PASTE]: goals vs results, value delivered, adoption gaps, roadmap asks, and a proposed expansion next step. Only use the numbers provided.
```

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
