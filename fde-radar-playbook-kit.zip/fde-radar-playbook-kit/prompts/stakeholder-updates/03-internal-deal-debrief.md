# Internal deal debrief

Category: Stakeholder updates

Fill in before you paste: [PASTE]

## Prompt

```text
Summarize this deal for my internal team from these notes [PASTE]: why we won/lost, what the customer actually valued, product gaps raised, and 3 lessons for the next similar deal.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
