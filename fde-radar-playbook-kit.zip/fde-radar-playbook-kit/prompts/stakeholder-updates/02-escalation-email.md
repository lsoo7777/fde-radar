# Escalation email

Category: Stakeholder updates

Fill in before you paste: [CUSTOMER EXEC], [ISSUE]

## Prompt

```text
Draft a calm escalation email to [CUSTOMER EXEC] about [ISSUE]: what happened, impact, what we've done, what we need from them, and the date of the next update. No blame, no hedging.
```

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
