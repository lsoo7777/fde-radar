# Runbook from tribal knowledge

Category: Implementation plans

Fill in before you paste: [PASTE], [SYSTEM]

## Prompt

```text
Here's a messy Slack thread about how we set up [SYSTEM] for a customer: [PASTE]. Turn it into a numbered runbook with prerequisites, steps, verification checks, and rollback steps. Mark anything the thread doesn't cover as GAP instead of filling it in.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
