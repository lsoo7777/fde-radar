# 30-60-90 implementation plan

Category: Implementation plans

Fill in before you paste: [CUSTOMER], [PRODUCT], [TEAM SIZE], [USE CASE]

## Prompt

```text
Create a 30-60-90 day implementation plan for [CUSTOMER] deploying [PRODUCT] for [USE CASE] with [TEAM SIZE]. Include milestones, dependencies, customer-side owners, risks, and what 'live' means at day 90.
```

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
