# Pass-rate report

Category: POC scoping

Fill in before you paste: [PASTE]

## Prompt

```text
Agreed criteria: [PASTE]. Eval results: [PASTE]. Report the pass rate for each criterion with counts (e.g. 27/30), say pass or fail against each threshold, list the failing ids, and give one concrete next fix. Use only the numbers provided.

(To agree the criteria first, use the poc-scope-that-gets-signed skill.)
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
