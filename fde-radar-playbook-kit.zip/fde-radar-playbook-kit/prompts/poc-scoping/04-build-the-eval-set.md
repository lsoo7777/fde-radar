# Build the eval set

Category: POC scoping

Fill in before you paste: [PASTE], [TASK]

## Prompt

```text
Here is the agent's task: [TASK]. Here are real example inputs, shared with permission: [PASTE]. For each input, write the expected output and 1-3 pass/fail checks a script or reviewer can apply. Mark ambiguous inputs AMBIGUOUS instead of choosing an answer, and list them for the customer to label.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
