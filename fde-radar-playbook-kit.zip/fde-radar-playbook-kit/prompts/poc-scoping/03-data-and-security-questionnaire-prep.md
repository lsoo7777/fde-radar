# Data and security questionnaire prep

Category: POC scoping

Fill in before you paste: [PASTE]

## Prompt

```text
The customer sent this security/IT questionnaire: [PASTE]. Using our documentation [PASTE], draft answers. Mark any question where our docs don't clearly support an answer as NEEDS REVIEW instead of guessing.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
