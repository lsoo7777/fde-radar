# Turn call notes into a deal summary

Category: Discovery

Fill in before you paste: [PASTE]

## Prompt

```text
Here are raw notes from a discovery call: [PASTE]. Rewrite them as: current state, desired outcome, metrics they care about, decision process, technical environment, risks, and open questions. Flag anything I assumed but they did not say.
```

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
