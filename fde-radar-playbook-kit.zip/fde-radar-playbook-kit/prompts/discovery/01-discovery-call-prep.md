# Discovery call prep

Category: Discovery

Fill in before you paste: [COMPANY], [INDUSTRY], [ONE-LINE PRODUCT], [PASTE], [ROLE OF ATTENDEES]

## Prompt

```text
I have a discovery call with [COMPANY], a [INDUSTRY] company, with [ROLE OF ATTENDEES]. Our product does [ONE-LINE PRODUCT]. Using only public info I paste below, list: 5 likely business pains, 10 open-ended discovery questions ranked by importance, and 3 signals that this is NOT a fit. Info: [PASTE]
```

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
