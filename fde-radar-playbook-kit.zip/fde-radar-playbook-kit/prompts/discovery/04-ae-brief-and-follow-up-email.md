# AE brief and follow-up email

Category: Discovery

Fill in before you paste: [PASTE]

## Prompt

```text
From this corrected deal summary [PASTE], write (1) a 5-bullet brief for my account executive: pain, deadline, must-haves, buying path, next step with date, and (2) a short follow-up email to the customer recapping what we heard and the agreed next steps. Use only facts in the summary.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
