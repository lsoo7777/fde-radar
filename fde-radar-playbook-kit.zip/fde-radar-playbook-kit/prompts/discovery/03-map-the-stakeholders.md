# Map the stakeholders

Category: Discovery

Fill in before you paste: [PASTE]

## Prompt

```text
From this email thread and call notes [PASTE], build a stakeholder map: name, title, what they care about, likely objection, influence (high/med/low). Suggest one question to ask each person next.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
