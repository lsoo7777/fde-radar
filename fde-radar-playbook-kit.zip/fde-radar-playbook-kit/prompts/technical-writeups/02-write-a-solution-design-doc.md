# Write a solution design doc

Category: Technical writeups

Fill in before you paste: [PASTE]

## Prompt

```text
Turn these notes into a solution design doc with sections: context, requirements, proposed design, integrations, data flow, security considerations, alternatives considered, open questions. Notes: [PASTE]
```

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
