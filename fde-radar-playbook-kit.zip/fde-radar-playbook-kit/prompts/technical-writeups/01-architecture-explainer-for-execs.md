# Architecture explainer for execs

Category: Technical writeups

Fill in before you paste: [PASTE DIAGRAM DESCRIPTION OR NOTES]

## Prompt

```text
Explain this integration architecture [PASTE DIAGRAM DESCRIPTION OR NOTES] to a non-technical VP in under 200 words: what connects to what, where their data goes, and what their team has to do. No jargon without a plain-English gloss.
```

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
