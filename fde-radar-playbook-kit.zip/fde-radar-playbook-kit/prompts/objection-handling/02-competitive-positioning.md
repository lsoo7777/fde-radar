# Competitive positioning

Category: Objection handling

Fill in before you paste: [COMPETITOR], [PASTE], [USE CASE]

## Prompt

```text
We're competing with [COMPETITOR] for [USE CASE]. From the public info I paste [PASTE], list where they are genuinely stronger, where we are, and 4 discovery questions that surface our strengths honestly. Don't invent claims about them.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
