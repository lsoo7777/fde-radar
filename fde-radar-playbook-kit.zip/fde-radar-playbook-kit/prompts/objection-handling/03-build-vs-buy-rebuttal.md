# Build vs buy rebuttal

Category: Objection handling

## Prompt

```text
The customer's engineering team says they can build this in-house. Draft a respectful talk track covering total cost of ownership, time to value, maintenance, and what they'd still own. Include 3 questions to quantify their build estimate.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
