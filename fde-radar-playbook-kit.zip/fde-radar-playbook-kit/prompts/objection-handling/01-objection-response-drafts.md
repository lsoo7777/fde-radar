# Objection response drafts

Category: Objection handling

Fill in before you paste: [DEAL CONTEXT], [OBJECTION]

## Prompt

```text
Prospect objection: "[OBJECTION]". Context: [DEAL CONTEXT]. Give 3 responses: one that asks a clarifying question, one that reframes with a business outcome, one that offers proof (POC, reference, doc). Keep each under 60 words.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
