# Build a tailored demo story

Category: Demo prep

Fill in before you paste: [LIST]

## Prompt

```text
Our product features: [LIST]. Prospect pains from discovery: [LIST]. Build a 20-minute demo flow: opening hook tied to their top pain, 3 scenes (pain → feature → outcome), and a close asking for a specific next step. Cut any feature that doesn't map to a pain.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
