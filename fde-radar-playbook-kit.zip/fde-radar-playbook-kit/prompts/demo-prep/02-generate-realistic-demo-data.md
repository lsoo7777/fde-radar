# Generate realistic demo data

Category: Demo prep

Fill in before you paste: [COLUMNS], [INDUSTRY], [USE CASE]

## Prompt

```text
Generate 25 rows of realistic but fake sample data for a [INDUSTRY] demo of [USE CASE] as CSV with columns [COLUMNS]. Include 3 edge cases that would make the demo more convincing. No real company or person names.
```

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
