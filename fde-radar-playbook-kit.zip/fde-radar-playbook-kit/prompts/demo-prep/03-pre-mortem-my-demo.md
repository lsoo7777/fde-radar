# Pre-mortem my demo

Category: Demo prep

Fill in before you paste: [BUYER ROLE], [PASTE]

## Prompt

```text
Here is my demo outline: [PASTE]. Act as a skeptical [BUYER ROLE]. List the 7 moments where you would lose interest or push back, and how I should fix each.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
