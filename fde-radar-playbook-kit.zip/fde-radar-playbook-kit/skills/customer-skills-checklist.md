# Customer skills checklist

Can you do each of these without help? Tick it off when you can.

- [ ] Run a discovery call that ends with clear pains, metrics and next step
- [ ] Build a demo tied to customer pains, not a feature tour
- [ ] Scope a POC with measurable pass/fail criteria
- [ ] Write a one-page solution design a VP can read
- [ ] Handle an objection by asking before answering
- [ ] Run a weekly status update with owners and dates
- [ ] Build a working integration end to end (API → data → output) and explain it

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
