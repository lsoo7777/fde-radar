# FDE learning path (16 free resources)

Tick each one off as you finish it.

## Technical foundations

- [ ] Command line, git, debugging basics: [MIT Missing Semester](https://missing.csail.mit.edu/)
- [ ] Git branching, interactively: [Learn Git Branching](https://learngitbranching.js.org/)
- [ ] CS fundamentals: [Harvard CS50x](https://cs50.harvard.edu/x/)
- [ ] Python: [LearnPython.org](https://www.learnpython.org/)
- [ ] SQL: [SQLBolt](https://sqlbolt.com/)
- [ ] HTTP & APIs: [MDN HTTP docs](https://developer.mozilla.org/en-US/docs/Web/HTTP)
- [ ] Containers: [Docker Get Started](https://docs.docker.com/get-started/)
- [ ] DevOps / cloud roadmap: [roadmap.sh DevOps](https://roadmap.sh/devops)
- [ ] Web dev end to end: [The Odin Project](https://www.theodinproject.com/)

## AI & LLM skills

- [ ] Prompt engineering (OpenAI): [OpenAI guide](https://platform.openai.com/docs/guides/prompt-engineering)
- [ ] Prompt engineering (Anthropic): [Anthropic guide](https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/overview)
- [ ] Prompting for developers: [DeepLearning.AI short course](https://learn.deeplearning.ai/courses/chatgpt-prompt-eng)
- [ ] LLMs & transformers: [Hugging Face LLM course](https://huggingface.co/learn/llm-course)
- [ ] Connecting AI to tools/data: [Model Context Protocol docs](https://modelcontextprotocol.io/introduction)

## Customer & presales skills

- [ ] Presales community and content: [PreSales Collective](https://www.presalescollective.com/)
- [ ] API testing for demos/POCs: [Postman API testing](https://www.postman.com/api-platform/api-testing/)

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
