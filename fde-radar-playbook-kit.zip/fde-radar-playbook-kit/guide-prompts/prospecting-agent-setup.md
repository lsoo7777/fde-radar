# How to set up a prospecting agent that researches and drafts, but never sends: prompts

From the guide: https://fderadar.com/prospecting-agent-setup.html (every step, rule and source is there).

Research and drafts only. The agent never sends, enrolls or changes your CRM; you review and send.

## Step 1: run it once by hand (Grok Bot official Sales Outbound starter prompt, https://docs.x.ai/grok-bot/use-cases)

```text
Research the 25 accounts in this CRM view. Score them against our ideal
customer profile (ICP) and recent intent, identify up to three relevant
contacts per account, and draft email and LinkedIn outreach in the style
examples attached. Skip anyone already in an active sequence. Return a review
list; do not send or enroll anyone.
```

## Step 5: turn it into a nightly routine

```text
Every weekday at 6 AM my time, run the prospecting process we just tested on
the accounts in [list or CRM view]. Only report accounts with a new signal
since the last run. Put drafts in my Gmail Drafts. Don't send, enroll or
change the CRM. If a source is unavailable, tell me instead of using old data.
```

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
