# Keep a personal prompt library

Save prompts that worked with your [BRACKET] variables. Our prompts page is a starting point.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
