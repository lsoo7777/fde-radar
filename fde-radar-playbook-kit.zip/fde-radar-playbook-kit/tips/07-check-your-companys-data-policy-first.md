# Check your company's data policy first

Don't paste customer data, credentials or contracts into tools your company hasn't approved.

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
