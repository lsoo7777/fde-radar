# Check your company's data policy first

Don't paste customer data, credentials or contracts into tools your company hasn't approved.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
