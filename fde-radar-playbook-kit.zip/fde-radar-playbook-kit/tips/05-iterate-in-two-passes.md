# Iterate in two passes

First ask for a draft, then ask it to critique the draft as the skeptical buyer, then revise.

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
