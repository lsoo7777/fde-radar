# Turn tribal knowledge into runbooks

Paste Slack threads and ask for numbered steps with verification and rollback. Then test the runbook once yourself.

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
