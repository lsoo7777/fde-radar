# Give the model the role and the reader

Say who it is writing as and for whom (e.g. 'a CFO who skims'). Output changes more from audience than from adjectives.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
