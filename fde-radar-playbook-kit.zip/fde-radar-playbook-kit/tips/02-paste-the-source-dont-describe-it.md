# Paste the source, don't describe it

Paste call notes, docs or logs. Summaries of summaries lose the details that matter.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
