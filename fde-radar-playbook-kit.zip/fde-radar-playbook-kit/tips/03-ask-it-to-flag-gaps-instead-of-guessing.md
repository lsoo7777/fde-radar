# Ask it to flag gaps instead of guessing

Add 'If the input doesn't support an answer, write NEEDS REVIEW.' This cuts made-up details in customer-facing work.

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
