# Use AI for demo data, not demo truth

Generate fake but realistic sample data; never let the model invent features your product doesn't have.

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
