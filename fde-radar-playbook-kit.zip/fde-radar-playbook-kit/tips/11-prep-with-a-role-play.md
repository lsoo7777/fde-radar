# Prep with a role-play

Ask the model to play the skeptical buyer or security reviewer and run through your demo or answers.

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
