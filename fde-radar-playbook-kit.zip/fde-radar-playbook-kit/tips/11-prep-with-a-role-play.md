# Prep with a role-play

Ask the model to play the skeptical buyer or security reviewer and run through your demo or answers.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
