# Use structure for reusable outputs

Request fixed sections or a table so status updates and POC docs look the same every week.

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
