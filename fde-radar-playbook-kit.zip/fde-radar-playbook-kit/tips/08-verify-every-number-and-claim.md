# Verify every number and claim

Treat model output as a draft. Check figures, product capabilities and competitor claims before they reach a customer.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
