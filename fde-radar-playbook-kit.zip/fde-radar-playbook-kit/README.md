# FDE Radar Playbook Kit

Free prompts, workflows, checklists and agent skills for Forward Deployed Engineers, Deployment Strategists and Solutions/Sales Engineers.

Updated Oct 2026 · https://fderadar.com

## What's inside

| Folder | What | Count |
|---|---|---|
| `prompts/` | Copy-paste prompts, one file each, grouped by category | 22 |
| `workflows/` | Step-by-step workflows with numbered steps | 12 |
| `agent-skills/` | The same workflows as `SKILL.md` files for Claude Code, Cursor and other agents | 12 |
| `skills/` | Checklists: a learning path (16 free resources) and customer skills (7 items) | 2 |
| `tips/` | Short tips for getting better output from AI tools | 12 |
| `PLAYBOOK.md` | Everything above in one file | 1 |

## Using the prompts with ChatGPT or Claude

1. Open a prompt file and copy the text inside the code block.
2. Replace every `[PLACEHOLDER]` (like `[COMPANY]` or `[PASTE]`) with your details. Each file lists its placeholders at the top.
3. Paste it into ChatGPT, Claude or your AI tool of choice.
4. Only paste customer information your company allows you to share with that tool.

Tip: in ChatGPT, save the ones you use most as a custom GPT or in a Project; in Claude, add them to a Project's instructions.

## Using the agent skills

Each folder in `agent-skills/` holds one `SKILL.md` with `name` and `description` frontmatter.

- **Claude Code:** copy the folders into `~/.claude/skills/` (all projects) or `.claude/skills/` in a repo.
- **Cursor and other agents:** copy them into whatever skills or rules folder your tool reads.

## Using the checklists

`skills/` holds markdown checklists (`- [ ]`). Open them in GitHub, Notion, Obsidian or any markdown editor and tick items off.

## Stay updated

New prompts and workflows every Friday in the free FDE Radar newsletter: https://fderadar.com/newsletter

Jobs, pay data and the full library: https://fderadar.com
