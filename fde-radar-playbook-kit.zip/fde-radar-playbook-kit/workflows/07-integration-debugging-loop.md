# Integration debugging loop

Category: Implementation · 5 steps

## Steps

1. Reproduce the issue and capture logs, request/response and environment.
2. Paste logs into the triage prompt for ranked root causes.
3. Test the top hypothesis with Postman or a small script.
4. Document the fix as a runbook entry.
5. Share a plain-English summary with the customer.

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
