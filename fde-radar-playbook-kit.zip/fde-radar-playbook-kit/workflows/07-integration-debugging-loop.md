# Integration debugging loop

Category: Implementation · 5 steps

## Steps

1. Reproduce the issue and capture logs, request/response and environment. Redact tokens, API keys, passwords and personal data before pasting anything into an AI tool.
2. Paste logs into the triage prompt for ranked root causes.
3. The user tests the top hypothesis with Postman, curl or a small script, and pastes the result back.
4. Document the fix as a runbook entry.
5. Share a plain-English summary with the customer.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
