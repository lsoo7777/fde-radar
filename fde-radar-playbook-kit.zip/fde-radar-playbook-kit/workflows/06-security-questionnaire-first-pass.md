# Security questionnaire first pass

Category: Security · 5 steps

## Steps

1. Gather your approved security docs (SOC 2 summary, DPA, architecture).
2. Prompt the AI to answer only from those docs and mark gaps NEEDS REVIEW.
3. Route NEEDS REVIEW items to security/legal owners.
4. Store final, approved answers in your RFP tool (e.g. Loopio, or Responsive, formerly RFPIO) for reuse.
5. Track turnaround time per questionnaire.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
