# POC scope that gets signed

Category: POC · 5 steps

## Steps

1. Draft the scope with the POC prompt (objective, criteria, timeline, owners).
2. Pressure-test each success criterion for measurability.
3. Review with the champion; agree on pass/fail before kickoff.
4. Turn the timeline into a shared checklist with dates.
5. Send a recap email confirming criteria in writing.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
