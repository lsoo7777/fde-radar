# EBR deck in an afternoon

Category: Stakeholders · 5 steps

## Steps

1. Export usage metrics and outcomes for the period.
2. Prompt the EBR outline using only the provided numbers.
3. Ask the user for one real customer story; take one adoption gap from the data. Mark anything missing [NEEDED].
4. Propose a specific next step grounded in the data; for commercial expansion, use the user's option and pricing, never invented numbers.
5. Rehearse with the champion before the exec meeting.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
