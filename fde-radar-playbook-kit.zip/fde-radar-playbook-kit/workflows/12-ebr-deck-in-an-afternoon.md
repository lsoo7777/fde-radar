# EBR deck in an afternoon

Category: Stakeholders · 5 steps

## Steps

1. Export usage metrics and outcomes for the period.
2. Prompt the EBR outline using only the provided numbers.
3. Add one customer story and one adoption gap.
4. Propose a specific expansion next step.
5. Rehearse with the champion before the exec meeting.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
