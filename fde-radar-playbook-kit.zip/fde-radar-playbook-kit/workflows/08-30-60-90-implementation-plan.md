# 30-60-90 implementation plan

Category: Implementation · 5 steps

## Steps

1. Feed scope, team size and success criteria into the 30-60-90 prompt.
2. Generate a risk register and add customer-specific risks.
3. Assign customer-side owners for every dependency.
4. Review in the kickoff meeting and get explicit agreement.
5. Turn milestones into weekly status-update headings.

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
