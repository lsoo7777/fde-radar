# 30-60-90 implementation plan

Category: Implementation · 5 steps

## Steps

1. Feed scope, team size and success criteria into the 30-60-90 prompt.
2. Generate a risk register and add customer-specific risks.
3. Ask the user for customer-side owners for every dependency; write TBD where none is given.
4. The user reviews the plan in the kickoff meeting and gets explicit agreement.
5. Turn milestones into weekly status-update headings.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
