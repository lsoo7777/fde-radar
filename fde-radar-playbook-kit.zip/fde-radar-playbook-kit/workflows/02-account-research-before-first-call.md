# Account research before first call

Category: Discovery · 5 steps

## Steps

1. Ask the user to paste the company's public info (site pages, latest 10-K or press releases) and the attendees' titles. If you have web access, you may read public pages yourself; cite the URL for every fact. Do not scrape LinkedIn.
2. Summarize business model, recent changes and likely priorities. Label every inferred pain or priority HYPOTHESIS.
3. Generate 10 discovery questions ranked by importance.
4. Flag 3 'not a fit' signals to watch for.
5. Return a one-page call plan with these sections: business model, recent changes, likely pains (hypotheses), 10 ranked questions, 3 not-a-fit signals, open questions.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
