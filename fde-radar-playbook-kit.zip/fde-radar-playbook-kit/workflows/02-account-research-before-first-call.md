# Account research before first call

Category: Discovery · 5 steps

## Steps

1. Collect the company's site, latest 10-K or press releases and the attendees' LinkedIn roles.
2. Prompt: summarize business model, likely priorities, recent changes.
3. Generate 10 discovery questions ranked by importance.
4. Flag 3 'not a fit' signals to watch for.
5. Save it as a one-page call plan.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
