# Deal debrief → product feedback

Category: Stakeholders · 5 steps

## Steps

1. After win/loss, paste notes into the debrief prompt.
2. Extract product gaps. Use only verbatim quotes that appear in the notes; if a gap has no quote, say so.
3. Group gaps by theme and deal size.
4. The user shares the gap list with product monthly in a single doc.
5. The user tracks which gaps ship and tells the customer.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
