# Deal debrief → product feedback

Category: Stakeholders · 5 steps

## Steps

1. After win/loss, paste notes into the debrief prompt.
2. Extract product gaps with customer quotes you actually heard.
3. Group gaps by theme and deal size.
4. Share with product monthly in a single doc.
5. Track which gaps ship and tell the customer.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
