# Agent POC with evals

Category: POC · 5 steps

## Steps

1. Pick one narrow task and collect 20–50 real example inputs (with permission).
2. Build the first version with an agent framework (e.g. LangGraph, OpenAI Agents SDK).
3. Write expected outputs and pass/fail checks for each input (first prompt), then run them through an eval tool (e.g. promptfoo, now part of OpenAI and still MIT open source, or DeepEval).
4. Trace failures with an observability tool (e.g. Langfuse, now part of ClickHouse and still open source, or LangSmith).
5. Report pass rate against the agreed criteria with the second prompt, not vibes. A zero-tolerance check that fails means the POC fails, whatever the average.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
