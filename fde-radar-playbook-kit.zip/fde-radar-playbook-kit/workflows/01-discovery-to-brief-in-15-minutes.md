# Discovery-to-brief in 15 minutes

Category: Discovery · 5 steps

## Steps

1. Record the call with an approved notetaker (e.g. Fathom, Granola).
2. Paste the transcript into your AI tool with the 'deal summary' prompt.
3. Ask it to list every assumption not stated by the customer.
4. Fix gaps, then generate a 5-bullet brief for your AE and a follow-up email draft.
5. Log the brief in CRM and set next-step dates.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
