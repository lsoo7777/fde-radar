# Discovery-to-brief in 15 minutes

Category: Discovery · 5 steps

## Steps

1. Get the customer's consent before recording, then record with a notetaker your company has approved (e.g. Fathom, Granola). If there is no recording, use your typed notes.
2. Paste the transcript into your AI tool with the 'deal summary' prompt.
3. Ask it to list every assumption not stated by the customer.
4. Fix gaps with the user, then generate a 5-bullet brief for the AE and a follow-up email draft (use the second prompt). Do not send the email.
5. The user logs the brief in CRM and sets next-step dates.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
