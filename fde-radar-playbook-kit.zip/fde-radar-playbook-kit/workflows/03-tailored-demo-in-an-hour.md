# Tailored demo in an hour

Category: Demo prep · 5 steps

## Steps

1. List the top 3 pains from discovery.
2. Prompt the demo-story template to map pain → feature → outcome.
3. Generate fake but realistic demo data as CSV; the user loads it into their sandbox.
4. Run the 'pre-mortem my demo' prompt as the skeptical buyer.
5. Suggest the user record a 3-minute walkthrough (e.g. Loom) for async stakeholders.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
