# Tailored demo in an hour

Category: Demo prep · 5 steps

## Steps

1. List the top 3 pains from discovery.
2. Prompt the demo-story template to map pain → feature → outcome.
3. Generate fake but realistic demo data as CSV and load it into your sandbox.
4. Run the 'pre-mortem my demo' prompt as the skeptical buyer.
5. Record a 3-minute Loom of the flow for async stakeholders.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
