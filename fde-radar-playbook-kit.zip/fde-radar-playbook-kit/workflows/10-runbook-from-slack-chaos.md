# Runbook from Slack chaos

Category: Implementation · 5 steps

## Steps

1. Export the relevant thread(s).
2. Prompt the AI to produce a numbered runbook with checks and rollback.
3. Follow the runbook yourself once on a test environment.
4. Fix steps that fail, then publish to your wiki.
5. Link the runbook in future tickets.

---
From FDE Radar (https://fderadar.com). New prompts and workflows every Friday: https://fderadar.com/newsletter
