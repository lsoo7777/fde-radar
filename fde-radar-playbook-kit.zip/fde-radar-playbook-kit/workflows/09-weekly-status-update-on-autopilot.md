# Weekly status update on autopilot

Category: Stakeholders · 5 steps

## Steps

1. Keep a running notes doc per customer during the week.
2. Friday: paste notes into the status prompt (RAG status, done, next, blockers).
3. Check every owner and date is real.
4. Return the email as a draft. The user sends it and pins it in the shared channel.
5. Escalate any red item with the escalation prompt the same day.

---
From FDE Radar (https://fderadar.com). Get the free FDE Radar newsletter: https://fderadar.com/newsletter
